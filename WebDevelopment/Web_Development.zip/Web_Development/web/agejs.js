const btn1= document.getElementById('btn')
const birth1= document.getElementById('birth')
const output = document.getElementById('output')

function calculate(){
    const birthday = birth1.value;
    if(birthday==""){
        alert("Please Enter the Birthday")
    }
    else{
        let age = getAge(birthday);
        output.innerHTML = `Your age is ${age} ${age > 1 ? "Years" : "Year"} old`;
    }
}

function getAge(birthday){
    const currentDate = new Date()
    const birthdayDate = new Date(birthday)
    let age = currentDate.getFullYear()-birthdayDate.getFullYear()
    const month = currentDate.getMonth()- birthdayDate.getMonth()

    if(month<0 || (month ==0 && currentDate.getDate()<birthdayDate.getDate())){
        age--
    }
    return age;
}
btn1.addEventListener("click", calculate);